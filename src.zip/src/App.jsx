import React, { useState } from "react";
import LoginPage from "./components/Auth/LoginPage";
import Register from "./pages/Register";

function App() {
  const [showRegister, setShowRegister] = useState(false);

  return (
    <>
      {showRegister ? (
        <Register />
      ) : (
        <LoginPage setShowRegister={setShowRegister} />
      )}
    </>
  );
}

export default App;
